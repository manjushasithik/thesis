# thesis > 2022-11-04 10:23pm
https://universe.roboflow.com/helmet-zsjlu/thesis-8lvsk

Provided by a Roboflow user
License: CC BY 4.0

